ekstrak dulu semua file nya bang trus langsung klik yang main.html aja

